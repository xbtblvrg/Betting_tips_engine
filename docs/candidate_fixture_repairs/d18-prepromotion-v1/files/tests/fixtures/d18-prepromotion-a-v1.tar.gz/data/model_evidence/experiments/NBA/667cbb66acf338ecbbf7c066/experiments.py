"""Predeclared recipe search on earlier data, followed by one champion test."""
from pathlib import Path
from datetime import timedelta
import hashlib,io,json,joblib
from .models import LeagueModel,RECIPES
from .domain import Game,parse_time,utcnow
from .providers import DATA
from .io_utils import atomic_json,atomic_bytes

PROTOCOL='chronological-recipe-search-v1'
HYPOTHESES={
 'baseline':'Reproduce the current model family as the development control.',
 'flexible_calibration':'Reduce shrinkage in probability calibration when forecasts cluster too tightly.',
 'strong_calibration':'Reduce calibration variance in a small or unstable sample.',
 'regularized':'Reduce variance in team features and score regression.',
 'richer_interactions':'Represent more nonlinear interactions with stronger tree regularization.',
 'elo_anchor':'Test an interpretable Elo-only probability component with separate calibration.',
}

def training_digest(games,league):
    rows=[(g.id,g.start,g.home_score,g.away_score,g.home_id,g.away_id,g.neutral,g.game_type,g.context.get('box'),
           sorted(g.context.get('pitching_observations') or [],key=lambda r:json.dumps(r,sort_keys=True)),
           (g.context.get('home_pitcher') or {}).get('id'),(g.context.get('away_pitcher') or {}).get('id'))
          for g in games if g.league==league and g.state=='final' and not g.context.get('resumed_game')]
    rows.sort(key=lambda r:(r[1],r[0]))
    return hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()

def choose_recipe(rows):
    eligible=[r for r in rows if not r.get('error') and r.get('brier') is not None]
    if len(eligible)!=len(RECIPES):raise ValueError('Incomplete experiment; resolve failed recipes before comparison')
    return min(eligible,key=lambda r:(r['brier'],r['log_loss'],r['recipe']))['recipe']

def earlier_history(games,cutoff):
    def available(game):
        start=parse_time(game.start)
        return max(start+timedelta(hours=8),start.replace(hour=0,minute=0,second=0,microsecond=0)+timedelta(days=1))
    return [g for g in games if parse_time(g.start)<cutoff and available(g)<=cutoff]

def score_gate(champion,challenger):
    checks={}
    for name in ('margin','total'):
        old=champion.report.get('score_mae',{}).get(name);new=challenger.report.get('score_mae',{}).get(name)
        checks[name]=old is not None and new is not None and new<=old*1.05
    return {'passed':all(checks.values()),'checks':checks,'maximum_relative_mae_regression':.05}

def run_study(league,data_dir=DATA,expected_digest=None):
    from .train import promotion_gate
    data=Path(data_dir);games=[Game(**g) for g in json.loads((data/'games.json').read_text())]
    digest=training_digest(games,league)
    if expected_digest is not None and digest!=expected_digest:
        return {'state':'superseded','reason':'Historical source changed before execution; queue a study for the new data.','profit_established':False}
    key=hashlib.sha256((PROTOCOL+league+digest+json.dumps(RECIPES,sort_keys=True)).encode()).hexdigest()[:24]
    folder=data/'experiments'/league/key;folder.mkdir(parents=True,exist_ok=True)
    result_path=folder/'result.json'
    if result_path.exists():return json.loads(result_path.read_text())
    champion_path=data/'models'/f'{league}.joblib';champion=joblib.load(champion_path)
    cutoff=parse_time(champion.report['test_from'])
    # Hard partition, not just a model flag: no final comparison outcome is
    # passed to the recipe-selection fits.
    earlier=earlier_history(games,cutoff)
    manifest={'protocol':PROTOCOL,'league':league,'training_digest':digest,'created_at':utcnow().isoformat(),
              'recipes':RECIPES,'hypotheses':HYPOTHESES,'selection_cutoff':cutoff.isoformat(),
              'comparison_model':champion.report['version'],
              'acceptance':'Select on earlier development data; paired outer Brier gate plus <=5% score-MAE regression.',
              'evaluation_status':'Retrospective development experiment; not proof of live profitability.'}
    atomic_json(folder/'manifest.json',manifest)
    rows=[]
    for recipe in RECIPES:
        model=LeagueModel(league,recipe).fit(earlier,as_of=cutoff)
        row={'recipe':recipe,'hypothesis':HYPOTHESES[recipe],**{k:model.report['test'][k] for k in ('n','brier','log_loss')},'last_game':model.report['last_game']}
        rows.append(row);atomic_json(folder/'development.json',rows)
    selected=choose_recipe(rows)
    challenger=LeagueModel(league,selected).fit(games)
    gate=promotion_gate(champion,challenger);scores=score_gate(champion,challenger)
    promote=gate['promote'] and scores['passed']
    result={'state':'completed','league':league,'protocol':PROTOCOL,'study_id':key,'training_digest':digest,
            'selected_recipe':selected,'development':rows,'comparison_model':champion.report['version'],
            'model_version':challenger.version,'promotion_gate':{**gate,'promote':promote,'score_guard':scores},
            'finished_at':utcnow().isoformat(),'profit_established':False,
            'next_action':'Monitor prospective outcomes of the promoted candidate.' if promote else 'Retain the deployed model; record hypothesis results and reevaluate when historical evidence changes.'}
    # Source can change during the study; do not overwrite a newly promoted
    # champion from another process with a comparison against an older one.
    current=joblib.load(champion_path)
    if current.report['version']!=champion.report['version']:
        result['promotion_gate']['promote']=False;result['next_action']='Champion changed during experiment; retain it and compare again.'
    latest=[Game(**g) for g in json.loads((data/'games.json').read_text())]
    if training_digest(latest,league)!=digest:
        result['promotion_gate']['promote']=False;result['next_action']='Historical data changed during experiment; compare the updated evidence.'
    challenger.report['promotion_gate']=result['promotion_gate'];challenger.report['experiment']=dict(manifest,study_id=key,selected_recipe=selected)
    buffer=io.BytesIO();joblib.dump(challenger,buffer)
    atomic_bytes(folder/'challenger.joblib',buffer.getvalue());atomic_json(folder/'challenger_report.json',challenger.report)
    for name in ('models.py','context.py','domain.py','contracts.py','experiments.py','train.py'):
        atomic_bytes(folder/name,(Path(__file__).parent/name).read_bytes())
    if result['promotion_gate']['promote']:
        atomic_bytes(champion_path,buffer.getvalue());atomic_json(data/'models'/f'{league}.json',challenger.report)
    atomic_json(result_path,result);return result
