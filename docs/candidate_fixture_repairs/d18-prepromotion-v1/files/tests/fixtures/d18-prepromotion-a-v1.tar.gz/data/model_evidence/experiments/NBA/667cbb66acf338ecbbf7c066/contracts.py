"""Full-game sportsbook contract identity and scalar/vector payoff conditions."""
SUPPORTED=('moneyline','spreads','totals','home_total','away_total')
PRICING_VERSION='full-game-contracts-v2'

def contract_key(tip):return 'contract:'+tip['id']

def contract_value(kind,side,line,home,away):
    if kind in ('moneyline','spreads'):
        if side not in ('home','away'):raise ValueError('Invalid team side')
        return (home-away)*(1 if side=='home' else -1)+(float(line) if kind=='spreads' else 0)
    if kind in ('totals','home_total','away_total'):
        if side not in ('over','under'):raise ValueError('Invalid total side')
        score=home+away if kind=='totals' else home if kind=='home_total' else away
        return (score-float(line))*(1 if side=='over' else -1)
    raise ValueError('Unsupported settlement contract')
