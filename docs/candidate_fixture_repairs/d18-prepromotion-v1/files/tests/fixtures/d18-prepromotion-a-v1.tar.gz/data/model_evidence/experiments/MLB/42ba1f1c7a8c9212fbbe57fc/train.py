"""Versioned training; daily candidates replace a champion only after a paired gate."""
from pathlib import Path
from collections import defaultdict
import json,logging,joblib,argparse,io
import numpy as np
from .providers import DATA,SportsData
from .domain import Game,LEAGUES,parse_time
from .models import LeagueModel
from .io_utils import atomic_json,atomic_bytes

def promotion_gate(champion,challenger):
    old={r['game_id']:r for r in champion.report.get('test_predictions',[])}
    pairs=[(old[r['game_id']],r) for r in challenger.report.get('test_predictions',[]) if r['game_id'] in old]
    if len(pairs)<150:return {'promote':False,'reason':'Kevés közös időben elkülönített tesztmeccs','paired_games':len(pairs)}
    weeks=defaultdict(list)
    for a,b in pairs:
        if a['result']!=b['result']:return {'promote':False,'reason':'Eltérő tesztcéladat; forrásfelülvizsgálat szükséges'}
        dt=parse_time(b['date']).isocalendar();weeks[(dt.year,dt.week)].append((b['p']-b['result'])**2-(a['p']-a['result'])**2)
    if len(weeks)<12:return {'promote':False,'reason':'Kevesebb mint 12 közös teszthét','paired_games':len(pairs)}
    blocks=[np.array(v) for v in weeks.values()];rng=np.random.default_rng(871)
    draws=[np.concatenate([blocks[i] for i in rng.integers(0,len(blocks),len(blocks))]).mean() for _ in range(1000)]
    lo,hi=map(float,np.quantile(draws,[.025,.975]))
    # Does not claim unseen prospective evidence; no architecture/feature self-rewrite.
    return {'promote':hi<0,'reason':'Páros heti Brier-ellenőrzés; nem profitigazolás','paired_games':len(pairs),'weeks':len(blocks),'delta_ci95':[lo,hi]}

def train(refresh=False,leagues=LEAGUES,controlled=False):
    if refresh or not (DATA/'games.json').exists():
        games,_=SportsData().load()
        from .context import SportContext,PitchingContext
        atomic_json(DATA/'context_sources.json',SportContext().enrich(games));atomic_json(DATA/'pitching_sources.json',PitchingContext().enrich(games));atomic_json(DATA/'games.json',[g.dict() for g in games])
    else:games=[Game(**g) for g in json.loads((DATA/'games.json').read_text())]
    out=DATA/'models';out.mkdir(parents=True,exist_ok=True);reports={}
    for league in leagues:
        try:
            destination=out/(league+'.joblib')
            champion=joblib.load(destination) if controlled and destination.exists() else None
            model=LeagueModel(league,champion.report.get('recipe','baseline') if champion else 'baseline').fit(games)
            gate=promotion_gate(champion,model) if champion else {'promote':True,'reason':'Első / kézzel indított fejlesztői modellkiadás'}
            model.report['promotion_gate']=gate
            archive=out/'versions'/model.version;archive.mkdir(parents=True,exist_ok=True)
            for name in ('models.py','context.py','domain.py'):atomic_bytes(archive/name,(Path(__file__).parent/name).read_bytes())
            buffer=io.BytesIO();joblib.dump(model,buffer);atomic_bytes(archive/'model.joblib',buffer.getvalue());atomic_json(archive/'report.json',model.report)
            if gate['promote']:atomic_bytes(destination,buffer.getvalue());atomic_json(out/(league+'.json'),model.report)
            reports[league]={k:v for k,v in model.report.items() if k!='test_predictions'}
            print(league,json.dumps({k:reports[league][k] for k in ['training_games','test','baseline','brier_delta_ci95','promotion_gate']},ensure_ascii=False),flush=True)
        except Exception as e:logging.exception('Training failed: %s',league);reports[league]={'error':str(e)}
    atomic_json(out/'summary.json',reports);return reports

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--refresh',action='store_true');parser.add_argument('--controlled',action='store_true');parser.add_argument('--league',choices=LEAGUES,action='append');args=parser.parse_args()
    train(args.refresh,args.league or LEAGUES,args.controlled)
